<?php
namespace MauticPlugin\MarketingFloorPromoBundle;

use Mautic\PluginBundle\Bundle\PluginBundleBase;

class MarketingFloorPromoBundle extends PluginBundleBase
{

}
