<?php

/*
 * @copyright   2016 Mautic Contributors. All rights reserved
 * @author      Mautic
 *
 * @link        http://mautic.org
 *
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

namespace MauticPlugin\MarketingFloorPromoBundle\Helper;

use MauticPlugin\MarketingFloorPromoBundle\Model\PromoModel;
use Symfony\Component\Routing\RouterInterface;

/**
 * Class TokenHelper.
 */
class TokenHelper
{
    private $regex = '{promo=(.*?)}';

    /**
     * @var PromoModel
     */
    protected $model;

    /**
     * @var RouterInterface
     */
    protected $router;
    /**
     * TokenHelper constructor.
     *
     * @param FormModel $model
     */
    public function __construct(PromoModel $model, RouterInterface $router)
    {
        $this->router = $router;
        $this->model  = $model;
    }

    /**
     * @param $content
     *
     * @return array
     */
    public function findPromoTokens($content)
    {
        $regex = '/'.$this->regex.'/i';

        preg_match_all($regex, $content, $matches);

        $tokens = [];

        if (count($matches[0])) {
            foreach ($matches[1] as $k => $id) {
                $token = '{promo='.$id.'}';
                $promo = $this->model->getEntity($id);
                if ($promo !== null
                    && (
                        $promo->isPublished()
                        || $this->security->hasEntityAccess(
                            'plugin:promo:items:viewown',
                            'plugin:promo:items:viewother',
                            $promo->getCreatedBy()
                        )
                    )
                ) {
                    $script = '<script src="'.$this->router->generate('mautic_promo_generate', ['id' => $id], true)
                        .'" type="text/javascript" charset="utf-8" async="async"></script>';
                    $tokens[$token] = $script;
                } else {
                    $tokens[$token] = '';
                }
            }
        }

        return $tokens;
    }
}
