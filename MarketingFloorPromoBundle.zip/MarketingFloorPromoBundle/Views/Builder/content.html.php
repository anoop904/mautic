<?php

/*
 * @copyright   2016 Mautic, Inc. All rights reserved
 * @author      Mautic, Inc
 *
 * @link        https://mautic.org
 *
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
$templateBase = 'MarketingFloorPromoBundle:Builder\\'.ucfirst($promo['style']).':index.html.php';
if (!isset($preview)) {
    $preview = false;
}

if (!isset($clickUrl)) {
    $clickUrl = '#';
}

$props = $promo['properties'];
?>

<div>
    <style scoped>
        .mautic-promo {
            font-family: <?php echo $props['content']['font']; ?>;
            color: #<?php echo $props['colors']['text']; ?>;
        }

        <?php if (isset($props['colors'])): ?>

        .mf-content a.mf-link, .mf-content .mauticform-button {
            background-color: #<?php echo $props['colors']['button']; ?>;
            color: #<?php echo $props['colors']['button_text']; ?>;
        }

        .mauticform-input:promo, select:promo {
            border: 1px solid #<?php echo $props['colors']['button']; ?>;
        }

        <?php endif; ?>
        <?php
        if (!empty($preview)):
            echo $view->render('MarketingFloorPromoBundle:Builder:style.less.php',
                [
                    'preview' => true,
                ]
            );
        endif;
        ?>
    </style>
    <?php echo $view->render(
        $templateBase,
        [
            'promo'    => $promo,
            'form'     => $form,
            'preview'  => $preview,
            'clickUrl' => $clickUrl,
        ]
    );

    // Add view tracking image
    if (!$preview): ?>

        <img src="<?php echo $view['router']->url(
            'mautic_promo_pixel',
            ['id' => $promo['id']],
            true
        ); ?>" alt="Mautic Promo" style="display: none;"/>
    <?php endif; ?>
</div>
