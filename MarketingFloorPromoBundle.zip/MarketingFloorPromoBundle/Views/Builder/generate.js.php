<?php

/*
 * @copyright   2016 Mautic, Inc. All rights reserved
 * @author      Mautic, Inc
 *
 * @link        https://mautic.org
 *
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
$style          = $promo['style'];
$props          = $promo['properties'];
$useScrollEvent = in_array($props['when'], ['scroll_slight', 'scroll_middle', 'scroll_bottom']);
$useUnloadEvent = ($props['when'] == 'leave');
$useTimeout     = (int) $props['timeout'];
if ($props['when'] == '5seconds') {
    $useTimeout = 5;
} elseif ($props['when'] == 'minute') {
    $useTimeout = 60;
}
if ($useTimeout) {
    $timeout = $useTimeout * 1000;
}

$debug          = ($app->getEnvironment() == 'dev') ? 'true' : 'false';
$animate        = (!isset($props['animate']) || !empty($props['animate']));
$linkActivation = (!isset($props['link_activation']) || !empty($props['link_activation']));

if (!isset($preview)) {
    $preview = false;
}

if (!isset($clickUrl)) {
    $clickUrl = $props['content']['link_url'];
}

$cssContent = $view->render(
    'MarketingFloorPromoBundle:Builder:style.less.php',
    [
        'preview' => $preview,
    ]
);
$cssContent = $view->escape($cssContent, 'js');

$parentCssContent = $view->render(
    'MarketingFloorPromoBundle:Builder:parent.less.php',
    [
        'preview' => $preview,
    ]
);
$parentCssContent = $view->escape($parentCssContent, 'js');

switch ($style) {
    case 'bar':
        $iframeClass = "mf-bar-iframe mf-bar-iframe-{$props['bar']['placement']} mf-bar-iframe-{$props['bar']['size']}";
        if ($props['bar']['sticky']) {
            $iframeClass .= ' mf-bar-iframe-sticky';
        }
        break;

    case 'modal':
    case 'notification':
        $placement   = str_replace('_', '-', $props[$style]['placement']);
        $iframeClass = "mf-{$style}-iframe mf-{$style}-iframe-{$placement}";
        break;

    default:
        $iframeClass = 'mf-'.$style.'-iframe';
        break;
}
?>

(function (window) {
    if (typeof window.MauticPromoParentHeadStyleInserted == 'undefined') {
        window.MauticPromoParentHeadStyleInserted = false;
    }

    window.MauticPromo<?php echo $promo['id']; ?> = function () {
        var Promo = {
            debug: <?php echo $debug; ?>,
            modalsDismissed: {},
            ignoreConverted: <?php echo ($promo['type'] !== 'notification' && !empty($props['stop_after_conversion'])) ? 'true' : 'false'; ?>,

            // Initialize the promo
            initialize: function () {
                if (Promo.debug)
                    console.log('initialize()');

                Promo.insertStyleIntoHead();
                Promo.registerPromoEvent();

                // Add class to body
                Promo.addClass(document.getElementsByTagName('body')[0], 'MauticPromo<?php echo ucfirst($style); ?>');
            },

            // Register click events for toggling bar, closing windows, etc
            registerClickEvents: function () {
                <?php if ($style == 'bar'): ?>
                var collapser = document.getElementsByClassName('mf-bar-collapser-<?php echo $promo['id']; ?>');

                collapser[0].addEventListener('click', function () {
                    Promo.toggleBarCollapse(collapser[0], false);
                });

                <?php else: ?>
                var closer = Promo.iframeDoc.getElementsByClassName('mf-<?php echo $style; ?>-close');
                var aTag = closer[0].getElementsByTagName('a');
                aTag[0].addEventListener('click', function (event) {
                    // Prevent multiple engagements for link clicks on exit intent
                    Promo.modalsDismissed["<?php echo $promo['id']; ?>"] = true;

                    // Remove iframe
                    Promo.iframe.parentNode.removeChild(Promo.iframe);

                    var overlays = document.getElementsByClassName('mf-modal-overlay-<?php echo $promo['id']; ?>');
                    if (overlays.length) {
                        overlays[0].parentNode.removeChild(overlays[0]);
                    }
                });
                <?php endif; ?>

                <?php if ($promo['type'] == 'click'): ?>
                var links = Promo.iframeDoc.getElementsByClassName('mf-link');
                if (links.length) {
                    links[0].addEventListener('click', function (event) {
                        Promo.convertVisitor();
                    });
                }
                <?php elseif ($promo['type'] == 'form'): ?>
                var buttons = Promo.iframeDoc.getElementsByClassName('mauticform-button');
                if (buttons.length) {
                    buttons[0].addEventListener('click', function (event) {
                        Promo.convertVisitor();
                    });
                }
                <?php endif; ?>
            },

            toggleBarCollapse: function (collapser, useCookie) {
                var svg = collapser.getElementsByTagName('svg');
                var g = svg[0].getElementsByTagName('g');
                var currentSize = svg[0].getAttribute('data-transform-size');
                var currentDirection = svg[0].getAttribute('data-transform-direction');
                var currentScale = svg[0].getAttribute('data-transform-scale');

                if (useCookie) {
                    if (Promo.cookies.hasItem('mf-bar-collapser-<?php echo $promo['id']; ?>')) {
                        var newDirection = Promo.cookies.getItem('mf-bar-collapser-<?php echo $promo['id']; ?>');
                        if (isNaN(newDirection)) {
                            var newDirection = currentDirection;
                        }
                    } else {
                        // Set cookie with current direction
                        var newDirection = currentDirection;
                    }
                } else {
                    var newDirection = (parseInt(currentDirection) * -1);
                    Promo.cookies.setItem('mf-bar-collapser-<?php echo $promo['id']; ?>', newDirection);
                }

                setTimeout(function () {
                    g[0].setAttribute('transform', 'scale(' + currentScale + ') rotate(' + newDirection + ' ' + currentSize + ' ' + currentSize + ')');
                    svg[0].setAttribute('data-transform-direction', newDirection);
                }, 500);

                var isTop = Promo.hasClass(Promo.iframePromo, 'mf-bar-top');
                if ((!isTop && newDirection == 90) || (isTop && newDirection == -90)) {
                    // Open it up
                    if (isTop) {
                        Promo.iframe.style.marginTop = 0;
                    } else {
                        Promo.iframe.style.marginBottom = 0;
                    }

                    Promo.removeClass(collapser, 'mf-bar-collapsed');
                    Promo.enableIframeResizer();

                } else {
                    // Collapse it
                    var iframeHeight = Promo.iframe.style.height;

                    iframeHeight.replace('px', '');
                    var newMargin = (parseInt(iframeHeight) * -1) + 'px';
                    if (isTop) {
                        Promo.iframe.style.marginTop = newMargin;
                    } else {
                        Promo.iframe.style.marginBottom = newMargin;
                    }

                    Promo.addClass(collapser, 'mf-bar-collapsed');
                    Promo.disableIFrameResizer();
                }
            },

            // Register scroll events, etc
            registerPromoEvent: function () {
                if (Promo.debug)
                    console.log('registerPromoEvent()');

                <?php if ($useScrollEvent): ?>
                if (Promo.debug)
                    console.log('scroll event registered');

                    <?php if ($useTimeout): ?>
                    if (Promo.debug)
                        console.log('timeout event registered');

                    setTimeout(function () {
                        window.addEventListener('scroll', Promo.engageVisitorAtScrollPosition);
                    }, <?php echo $timeout; ?>);

                    <?php else: ?>

                     window.addEventListener('scroll', Promo.engageVisitorAtScrollPosition);

                   <?php endif; ?>

                <?php elseif ($useUnloadEvent): ?>
                if (Promo.debug)
                    console.log('show when visitor leaves');

                    <?php if ($useTimeout): ?>
                    if (Promo.debug)
                        console.log('timeout event registered');

                    setTimeout(function () {
                        document.documentElement.addEventListener('mouseleave', Promo.engageVisitor);
                    }, <?php echo $timeout; ?>);

                    <?php else: ?>

                    document.documentElement.addEventListener('mouseleave', Promo.engageVisitor);

                    <?php endif; ?>

                // Add a listener to every link
                <?php if ($linkActivation): ?>

                var elements = document.getElementsByTagName('a');

                for (var i = 0, len = elements.length; i < len; i++) {
                    var href = elements[i].getAttribute('href');
                    if (href && href.indexOf('#') != 0 && href.indexOf('javascript:') != 0) {
                        elements[i].onclick = function (event) {
                            if (typeof Promo.modalsDismissed["<?php echo $promo['id']; ?>"] == 'undefined') {
                                if (Promo.engageVisitor()) {
                                    event.preventDefault();
                                }
                            }
                        }
                    }
                }
                <?php endif; ?>

                <?php else: ?>
                if (Promo.debug)
                    console.log('show immediately');

                    <?php if ($useTimeout): ?>
                    if (Promo.debug)
                        console.log('timeout event registered');

                    setTimeout(function () {
                        // Give a slight delay to allow browser to process style injection into header
                        Promo.engageVisitor();
                    }, <?php echo $timeout; ?>);

                    <?php else: ?>

                    // Give a slight delay to allow browser to process style injection into header
                    Promo.engageVisitor();

                    <?php endif; ?>

                <?php endif; ?>
            },

            // Insert global style into page head
            insertStyleIntoHead: function () {
                if (!window.MauticPromoParentHeadStyleInserted) {
                    if (Promo.debug)
                        console.log('insertStyleIntoHead()');

                    var css = "<?php echo $parentCssContent; ?>",
                        head = document.head || document.getElementsByTagName('head')[0],
                        style = document.createElement('style');

                    head.appendChild(style);
                    style.type = 'text/css';
                    if (style.styleSheet) {
                        style.styleSheet.cssText = css;
                    } else {
                        style.appendChild(document.createTextNode(css));
                    }
                } else if (Promo.debug) {
                    console.log('Shared style already inserted into head');
                }
            },

            // Inserts styling into the iframe's head
            insertPromoStyleIntoIframeHead: function () {
                // Insert style into iframe header
                var frameDoc = Promo.iframe.contentDocument;
                var frameHead = frameDoc.getElementsByTagName('head').item(0);

                var css = "<?php echo $cssContent; ?>";
                var style = frameDoc.createElement('style');

                style.type = 'text/css';
                if (style.styleSheet) {
                    style.styleSheet.cssText = css;
                } else {
                    style.appendChild(frameDoc.createTextNode(css));
                }
                frameHead.appendChild(style);

                var metaTag = frameDoc.createElement('meta');
                metaTag.name = "viewport"
                metaTag.content = "width=device-width,initial-scale=1,minimum-scale=1.0 maximum-scale=1.0"
                frameHead.appendChild(metaTag);
            },

            // Generates the promo HTML
            engageVisitor: function () {
                var now = Math.floor(Date.now() / 1000);

                if (Promo.cookies.hasItem('mautic_promo_<?php echo $promo['id']; ?>')) {
                    if (Promo.debug)
                        console.log('Cookie exists thus checking frequency');

                    var lastEngaged = parseInt(Promo.cookies.getItem('mautic_promo_<?php echo $promo['id']; ?>')),
                        frequency = '<?php echo $props['frequency']; ?>',
                        engage;

                    if (Promo.ignoreConverted && lastEngaged == -1) {
                        if (Promo.debug)
                            console.log('Visitor converted; abort');

                        return false;
                    }

                    switch (frequency) {
                        case 'once':
                            engage = false;
                            if (Promo.debug)
                                console.log('Engage once, abort');

                            break;
                        case 'everypage':
                            engage = true;
                            if (Promo.debug)
                                console.log('Engage on every page, continue');

                            break;
                        case 'q2min':
                            engage = (now - lastEngaged) >= 120;
                            if (Promo.debug) {
                                var debugMsg = 'Engage q2 minute, ';
                                if (engage) {
                                    debugMsg += 'continue';
                                } else {
                                    debugMsg += 'engage in ' + (120 - (now - lastEngaged)) + ' seconds';
                                }
                                console.log(debugMsg);
                            }

                            break;
                        case 'q15min':
                            engage = (now - lastEngaged) >= 900;
                            if (Promo.debug) {
                                var debugMsg = 'Engage q15 minute, ';
                                if (engage) {
                                    debugMsg += 'continue';
                                } else {
                                    debugMsg += 'engage in ' + (120 - (now - lastEngaged)) + ' seconds';
                                }
                                console.log(debugMsg);
                            }

                            break;
                        case 'hourly':
                            engage = (now - lastEngaged) >= 3600;
                            if (Promo.debug) {
                                var debugMsg = 'Engage hourly, ';
                                if (engage) {
                                    debugMsg += 'continue';
                                } else {
                                    debugMsg += 'engage in ' + (120 - (now - lastEngaged)) + ' seconds';
                                }
                                console.log(debugMsg);
                            }

                            break;
                        case 'daily':
                            engage = (now - lastEngaged) >= 86400;
                            if (Promo.debug) {
                                var debugMsg = 'Engage daily, ';
                                if (engage) {
                                    debugMsg += 'continue';
                                } else {
                                    debugMsg += 'engage in ' + (120 - (now - lastEngaged)) + ' seconds';
                                }
                                console.log(debugMsg);
                            }

                            break;
                    }

                    if (!engage) {

                        return false;
                    }
                }

                if (Promo.debug)
                    console.log('engageVisitor()');

                // Inject iframe
                Promo.createIframe();

                // Inject content into iframe
                Promo.iframeDoc.open();
                <?php
                $content = $view->render(
                    'MarketingFloorPromoBundle:Builder:content.html.php',
                    [
                        'promo'    => $promo,
                        'form'     => $form,
                        'clickUrl' => $clickUrl,
                    ]
                );

                if (empty($ignoreMinify)) {
                    $content = \Minify_HTML::minify($content);
                }

                $content = $view->escape($content, 'js');
                ?>

                Promo.iframeDoc.write("<?php echo $content; ?>");
                Promo.iframeDoc.close();

                // Set body margin to 0
                Promo.iframeDoc.getElementsByTagName('body')[0].style.margin = 0;

                // Find elements that should be moved to parent
                var move = Promo.iframeDoc.getElementsByClassName('mf-move-to-parent');
                for (var i = 0; i < move.length; i++) {
                    var bodyFirstChild = document.body.firstChild;
                    bodyFirstChild.parentNode.insertBefore(move[i], Promo.iframe);
                }

                // Find elements that should be copied to parent
                var copy = Promo.iframeDoc.getElementsByClassName('mf-copy-to-parent');
                for (var i = 0; i < copy.length; i++) {
                    var bodyFirstChild = document.body.firstChild;
                    var clone = copy[i].cloneNode(true);
                    bodyFirstChild.parentNode.insertBefore(clone, Promo.iframe);
                }

                // Get the main promo element
                var promo = Promo.iframeDoc.getElementsByClassName('mautic-promo');
                Promo.iframePromo = promo[0];

                // Insert style into iframe head
                Promo.insertPromoStyleIntoIframeHead();

                // Register events
                Promo.registerClickEvents();

                // Resize iframe
                var animate = <?php echo ($animate) ? 'true' : 'false'; ?>;
                if (Promo.enableIframeResizer()) {
                    // Give iframe chance to resize
                    setTimeout(function () {
                        if (animate) {
                            Promo.addClass(Promo.iframe, "mf-animate");
                        }
                        Promo.addClass(Promo.iframe, "mf-loaded");
                    }, 35);
                } else {
                    if (animate) {
                        Promo.addClass(Promo.iframe, "mf-animate");
                    }
                    Promo.addClass(Promo.iframe, "mf-loaded");
                }

                <?php if ($props['when'] == 'leave'): ?>
                // Ensure user can leave
                document.documentElement.removeEventListener('mouseleave', Promo.engageVisitor);
                <?php endif; ?>

                // Add cookie of last engagement
                if (Promo.debug)
                    console.log('mautic_promo_<?php echo $promo['id']; ?> cookie set for ' + now);

                Promo.cookies.removeItem('mautic_promo_<?php echo $promo['id']; ?>');
                Promo.cookies.setItem('mautic_promo_<?php echo $promo['id']; ?>', now, Infinity);

                <?php if ($style == 'bar'): ?>
                var collapser = document.getElementsByClassName('mf-bar-collapser-<?php echo $promo['id']; ?>');

                if (animate) {
                    // Give iframe chance to resize
                    setTimeout(function () {
                        Promo.toggleBarCollapse(collapser[0], true);
                    }, 35);
                } else {
                    Promo.toggleBarCollapse(collapser[0], true);
                }
                <?php endif; ?>

                return true;
            },

            // Enable iframe resizer
            enableIframeResizer: function () {
                <?php if (in_array($style, ['modal', 'notification', 'bar'])): ?>
                Promo.iframeHeight = 0;
                Promo.iframeWidth = 0;
                Promo.iframeResizeInterval = setInterval(function () {
                    if (Promo.iframeHeight !== Promo.iframe.style.height) {
                        var useHeight = ((window.innerHeight < Promo.iframePromo.offsetHeight) ?
                            window.innerHeight : Promo.iframePromo.offsetHeight);

                        useHeight += 10;
                        useHeight = useHeight + 'px';


                        if (Promo.debug) {
                            console.log('window inner height = ' + window.innerHeight);
                            console.log('iframe offset height = ' + Promo.iframePromo.offsetHeight);
                            console.log('iframe height set to ' + useHeight)
                        }
                        ;
                        Promo.iframe.style.height = useHeight;
                        Promo.iframeHeight = useHeight;
                    }

                    <?php if (in_array($style, ['modal', 'notification'])): ?>
                    if (Promo.iframeWidth !== Promo.iframe.style.width) {
                        if (Promo.debug) {
                            console.log('window inner width = ' + window.innerWidth);
                            console.log('iframe offset width = ' + Promo.iframePromo.offsetWidth);
                        }

                        if (window.innerWidth < Promo.iframePromo.offsetWidth) {
                            // Responsive iframe
                            Promo.addClass(Promo.iframePromo, 'mf-responsive');
                            Promo.addClass(Promo.iframe, 'mf-responsive');
                            Promo.iframe.style.width = window.innerWidth + 'px';
                            Promo.iframe.width = window.innerWidth;
                            if (Promo.debug)
                                console.log('iframe set to responsive width: ');

                        } else {
                            Promo.iframe.style.width = Promo.iframePromo.offsetWidth + 'px';
                            Promo.iframe.width = Promo.iframePromo.offsetWidth + 'px';
                            Promo.removeClass(Promo.iframePromo, 'mf-responsive');
                            Promo.removeClass(Promo.iframe, 'mf-responsive');

                            if (Promo.debug)
                                console.log('iframe not a responsive width');
                        }

                        Promo.iframeWidth = Promo.iframe.style.width;
                    }
                    <?php endif; ?>
                }, 35);

                return true;
                <?php endif; ?>

                return false;
            },

            // Disable iframe resizer
            disableIFrameResizer: function () {
                <?php if (in_array($style, ['modal', 'notification', 'bar'])): ?>
                clearInterval(Promo.iframeResizeInterval);
                <?php endif; ?>
            },

            // Create iframe to load into body
            createIframe: function () {
                if (Promo.debug)
                    console.log('createIframe()');

                Promo.iframe = document.createElement('iframe');
                Promo.iframe.style.border = 0;
                Promo.iframe.style.width = "100%";
                Promo.iframe.style.height = "100%";
                Promo.iframe.src = "about:blank";
                Promo.iframe.scrolling = "no";
                Promo.iframe.className = "<?php echo $iframeClass; ?>";

                var bodyFirstChild = document.body.firstChild;
                bodyFirstChild.parentNode.insertBefore(Promo.iframe, bodyFirstChild);

                Promo.iframeDoc = Promo.iframe.contentWindow.document;
            },

            // Execute event at current position
            engageVisitorAtScrollPosition: function (event) {
                var visualHeight = "innerHeight" in window
                    ? window.innerHeight
                    : document.documentElement.offsetHeight;

                var scrollPos = window.pageYOffset,
                    atPos = 0;

                <?php switch ($props['when']):
                case 'scroll_slight': ?>
                atPos = 10;
                <?php break; ?>

                <?php case 'scroll_middle': ?>
                scrollPos += (visualHeight / 2);
                atPos = (document.body.scrollHeight / 2);
                <?php break; ?>

                <?php case 'scroll_bottom': ?>
                scrollPos += visualHeight;
                atPos = document.body.scrollHeight;
                <?php break; ?>

                <?php endswitch; ?>

                if (Promo.debug)
                    console.log('scrolling: ' + scrollPos + ' >= ' + atPos);

                if (scrollPos >= atPos) {
                    window.removeEventListener('scroll', Promo.engageVisitorAtScrollPosition);
                    Promo.engageVisitor();
                }
            },

            // Create cookie noting visitor has been converted if applicable
            convertVisitor: function () {
                if (Promo.ignoreConverted) {
                    if (Promo.debug)
                        console.log('Visitor converted');

                    Promo.cookies.setItem('mautic_promo_<?php echo $promo['id']; ?>', -1, Infinity);
                } else if (Promo.debug) {
                    console.log('Visitor converted but ignoreConverted not enabled');
                }
            },

            // Element has class
            hasClass: function (element, hasClass) {
                return ( (" " + element.className + " ").replace(/[\n\t]/g, " ").indexOf(" " + hasClass + " ") > -1 );
            },

            // Add class to element
            addClass: function (element, addClass) {
                if (!Promo.hasClass(element, addClass)) {
                    element.className += " " + addClass;
                }
            },

            // Remove class from element
            removeClass: function (element, removeClass) {
                element.className = element.className.replace(new RegExp('\\b' + removeClass + '\\b'), '');
            },

            // Cookie handling
            cookies: {
                /**
                 * :: cookies.js ::
                 * https://developer.mozilla.org/en-US/docs/Web/API/document.cookie
                 * http://www.gnu.org/licenses/gpl-3.0-standalone.html
                 */
                getItem: function (sKey) {
                    if (!sKey) {
                        return null;
                    }
                    return decodeURIComponent(document.cookie.replace(new RegExp("(?:(?:^|.*;)\\s*" + encodeURIComponent(sKey).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=\\s*([^;]*).*$)|^.*$"), "$1")) || null;
                },
                setItem: function (sKey, sValue, vEnd, sPath, sDomain, bSecure) {
                    if (!sKey || /^(?:expires|max\-age|path|domain|secure)$/i.test(sKey)) {
                        return false;
                    }

                    this.removeItem(sKey);

                    var sExpires = "";
                    if (vEnd) {
                        switch (vEnd.constructor) {
                            case Number:
                                sExpires = vEnd === Infinity ? "; expires=Fri, 31 Dec 9999 23:59:59 GMT" : "; max-age=" + vEnd;
                                break;
                            case String:
                                sExpires = "; expires=" + vEnd;
                                break;
                            case Date:
                                sExpires = "; expires=" + vEnd.toUTCString();
                                break;
                        }
                    }
                    document.cookie = encodeURIComponent(sKey) + "=" + encodeURIComponent(sValue) + sExpires + (sDomain ? "; domain=" + sDomain : "") + (sPath ? "; path=" + sPath : "") + (bSecure ? "; secure" : "");
                    return true;
                },
                removeItem: function (sKey, sPath, sDomain) {
                    if (!this.hasItem(sKey)) {
                        return false;
                    }
                    document.cookie = encodeURIComponent(sKey) + "=; expires=Thu, 01 Jan 1970 00:00:00 GMT" + (sDomain ? "; domain=" + sDomain : "") + (sPath ? "; path=" + sPath : "");
                    return true;
                },
                hasItem: function (sKey) {
                    if (!sKey) {
                        return false;
                    }
                    return (new RegExp("(?:^|;\\s*)" + encodeURIComponent(sKey).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=")).test(document.cookie);
                },
                keys: function () {
                    var aKeys = document.cookie.replace(/((?:^|\s*;)[^\=]+)(?=;|$)|^\s*|\s*(?:\=[^;]*)?(?:\1|$)/g, "").split(/\s*(?:\=[^;]*)?;\s*/);
                    for (var nLen = aKeys.length, nIdx = 0; nIdx < nLen; nIdx++) {
                        aKeys[nIdx] = decodeURIComponent(aKeys[nIdx]);
                    }
                    return aKeys;
                }
            }
        };

        return Promo;
    }

    // Initialize
    MauticPromo<?php echo $promo['id']; ?>().initialize();
})(window);
