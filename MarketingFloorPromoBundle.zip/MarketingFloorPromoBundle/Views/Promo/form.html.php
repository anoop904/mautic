<?php

/*
 * @copyright   2016 Mautic, Inc. All rights reserved
 * @author      Mautic, Inc
 *
 * @link        https://mautic.org
 *
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
$view->extend('MauticCoreBundle:Default:content.html.php');
$view['slots']->set('mauticContent', 'promo');

$header = ($entity->getId())
    ?
    $view['translator']->trans(
        'mautic.promo.edit',
        ['%name%' => $view['translator']->trans($entity->getName())]
    )
    :
    $view['translator']->trans('mautic.promo.new');
$view['slots']->set('headerTitle', $header);

echo $view['assets']->includeScript('plugins/MarketingFloorPromoBundle/Assets/js/promo.js');
echo $view['assets']->includeStylesheet('plugins/MarketingFloorPromoBundle/Assets/css/promo.css');

echo $view['form']->start($form);
?>
    <!-- start: box layout -->
    <div class="box-layout">
        <!-- container -->
        <div class="col-md-9 bg-auto height-auto bdr-r pa-md">
            <div class="row">
                <div class="col-md-6">
                    <?php echo $view['form']->row($form['name']); ?>
                </div>
                <div class="col-md-6">
                    <?php echo $view['form']->row($form['website']); ?>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <?php echo $view['form']->row($form['description']); ?>
                </div>
            </div>
        </div>
        <div class="col-md-3 bg-white height-auto">
            <div class="pr-lg pl-lg pt-md pb-md">
                <?php
                echo $view['form']->row($form['category']);
                echo $view['form']->row($form['isPublished']);
                echo $view['form']->row($form['publishUp']);
                echo $view['form']->row($form['publishDown']);
                ?>
            </div>
        </div>
    </div>

    <div class="hide builder promo-builder">
        <div class="builder-content">
            <div class="website-preview">
                <div class="website-placeholder hide well well-lg col-md-6 col-md-offset-3 mt-lg">
                    <div class="row">
                        <div class="mautibot-image col-xs-3 text-center">
                            <img class="img-responsive" style="max-height: 125px; margin-left: auto; margin-right: auto;" src="<?php echo $view['mautibot']->getImage(
                                'wave'
                            ); ?>"/>
                        </div>
                        <div class="col-xs-9">
                            <h4><i class="fa fa-quote-left"></i> <?php echo $view['translator']->trans('mautic.core.noresults.tip'); ?>
                                <i class="fa fa-quote-right"></i></h4>
                            <p class="mt-md">
                                <?php echo $view['translator']->trans('mautic.promo.website_placeholder'); ?>
                            </p>
                            <div class="input-group">
                                <input id="websiteUrlPlaceholderInput" disabled type="text" class="form-control" placeholder="http..."/>
                                <span class="input-group-btn">
                                <button class="btn btn-default btn-fetch" type="button"><?php echo $view['translator']->trans(
                                        'mautic.promo.fetch_snapshot'
                                    ); ?></button>
                            </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="viewport-switcher text-center bdr-t-sm bdr-b-sm bdr-r-sm">
                    <div class="btn btn-sm btn-success btn-nospin btn-viewport" data-viewport="desktop">
                        <i class="fa fa-mobile-phone fa-3x"></i>
                    </div>
                </div>
                <figure id="websiteScreenshot">
                    <div class="screenshot-container text-center">
                        <div class="preview-body text-left"></div>
                        <canvas id="websiteCanvas">
                            Your browser does not support the canvas element.
                        </canvas>
                    </div>
                </figure>
            </div>
        </div>
        <div class="builder-panel builder-panel-promo">
            <div class="builder-panel-top">
                <p>
                    <button type="button" class="btn btn-primary btn-close-builder btn-block" onclick="Mautic.closePromoBuilder(this);"><?php echo $view['translator']->trans(
                            'mautic.core.close.builder'
                        ); ?></button>
                </p>
            </div>
            <?php
            $class = ($form['type']->vars['data']) ? 'promo-type-'.$form['type']->vars['data'] : 'promo-type-all';
            $class .= ($form['style']->vars['data']) ? ' promo-style-'.$form['style']->vars['data'] : ' promo-style-all';
            ?>
            <div class="<?php echo $class; ?>" style="margin-top: 40px;" id="promoFormContent">
                <!-- start promo type  -->
                <div class="panel panel-default" id="promoType">
                    <div class="panel-heading">
                        <h4 class="promo-type-header panel-title">
                            <a role="button" data-toggle="collapse" href="#promoTypePanel" aria-expanded="true" aria-controls="promoTypePanel">
                                <i class="fa fa-bullseye"></i> <?php echo $view['translator']->trans('mautic.promo.form.type'); ?>
                            </a>
                        </h4>
                    </div>
                    <div id="promoTypePanel" class="panel-collapse collapse in" role="tabpanel">
                        <?php echo $view['form']->widget($form['type']); ?>
                        <ul class="list-group mb-0">
                            <li data-promo-type="form" class="promo-type list-group-item pl-sm pr-sm">
                                <div class="row">
                                    <div class="col-xs-2">
                                        <i class="fa fa-2x fa-pencil-square-o text-primary"></i>
                                    </div>
                                    <div class="col-xs-10">
                                        <h4 class="list-group-heading"><?php echo $view['translator']->trans('mautic.promo.form.type.form'); ?></h4>
                                        <p class="list-group-item-text small"><?php echo $view['translator']->trans(
                                                'mautic.promo.form.type.form_description'
                                            ); ?></p>
                                    </div>
                                </div>
                            </li>

                            <li class="promo-properties promo-form-properties list-group-item pl-sm pr-sm" style="display: none;"></li>

                            <li data-promo-type="notice" class="promo-type list-group-item pl-sm pr-sm">
                                <div class="row">
                                    <div class="col-xs-2">
                                        <i class="fa fa-2x fa-bullhorn text-warning"></i>
                                    </div>
                                    <div class="col-xs-10">
                                        <h4 class="list-group-heading"><?php echo $view['translator']->trans('mautic.promo.form.type.notice'); ?></h4>
                                        <p class="list-group-item-text small"><?php echo $view['translator']->trans(
                                                'mautic.promo.form.type.notice_description'
                                            ); ?></p>
                                    </div>
                                </div>
                            </li>

                            <li class="promo-properties promo-notice-properties list-group-item pl-sm pr-sm" style="display: none;"></li>

                            <li data-promo-type="link" class="promo-type list-group-item pl-sm pr-sm">
                                <div class="row">
                                    <div class="col-xs-2">
                                        <i class="fa fa-2x fa-hand-o-right text-info"></i>
                                    </div>
                                    <div class="col-xs-10">
                                        <h4 class="list-group-heading"><?php echo $view['translator']->trans('mautic.promo.form.type.link'); ?></h4>
                                        <p class="list-group-item-text small"><?php echo $view['translator']->trans(
                                                'mautic.promo.form.type.link_description'
                                            ); ?></p>
                                    </div>
                                </div>
                            </li>

                            <li class="promo-properties promo-link-properties list-group-item pl-sm pr-sm" style="display: none;"></li>
                        </ul>
                    </div>

                    <div class="hide" id="promoTypeProperties">
                        <?php echo $view['form']->row($form['properties']['animate']); ?>
                        <?php echo $view['form']->row($form['properties']['when']); ?>
                        <?php echo $view['form']->row($form['properties']['timeout']); ?>
                        <?php echo $view['form']->row($form['properties']['link_activation']); ?>
                        <?php echo $view['form']->row($form['properties']['frequency']); ?>
                        <div class="hidden-promo-type-notice">
                            <?php echo $view['form']->row($form['properties']['stop_after_conversion']); ?>
                        </div>
                    </div>
                </div>
                <!-- end promo type -->

                <!-- start promo type tab -->
                <div class="panel panel-default" id="promoStyle">
                    <div class="panel-heading">
                        <h4 class="panel-title promo-style-header">
                            <a role="button" data-toggle="collapse" href="#promoStylePanel" aria-expanded="true" aria-controls="promoStylePanel">
                                <i class="fa fa-desktop"></i> <?php echo $view['translator']->trans('mautic.promo.form.style'); ?>
                            </a>
                        </h4>
                    </div>
                    <div id="promoStylePanel" class="panel-collapse collapse" role="tabpanel">
                        <ul class="list-group mb-0">
                            <li data-promo-style="bar" class="promo-style visible-promo-style-bar list-group-item pl-sm pr-sm">
                                <div class="row">
                                    <div class="col-xs-2">
                                        <i class="pl-2 fa fa-2x fa-minus text-primary"></i>
                                    </div>
                                    <div class="col-xs-10">
                                        <h4 class="list-group-heading"><?php echo $view['translator']->trans('mautic.promo.style.bar'); ?></h4>
                                        <p class="list-group-item-text small"><?php echo $view['translator']->trans(
                                                'mautic.promo.style.bar_description'
                                            ); ?></p>
                                    </div>
                                </div>
                            </li>
                            <li class="promo-properties promo-bar-properties list-group-item pl-sm pr-sm" style="display: none;"></li>

                            <li data-promo-style="modal" class="promo-style visible-promo-style-modal list-group-item pl-sm pr-sm">
                                <div class="row">
                                    <div class="col-xs-2">
                                        <i class="fa fa-2x fa-list-alt text-warning"></i>
                                    </div>
                                    <div class="col-xs-10">
                                        <h4 class="list-group-heading"><?php echo $view['translator']->trans('mautic.promo.style.modal'); ?></h4>
                                        <p class="list-group-item-text small"><?php echo $view['translator']->trans(
                                                'mautic.promo.style.modal_description'
                                            ); ?></p>
                                    </div>
                                </div>
                            </li>
                            <li class="promo-properties promo-modal-properties list-group-item pl-sm pr-sm" style="display: none;"></li>

                            <li data-promo-style="notification" class="promo-style visible-promo-style-notification list-group-item pl-sm pr-sm">
                                <div class="row">
                                    <div class="col-xs-2">
                                        <i class="pl-2 fa fa-2x fa-info-circle text-info"></i>
                                    </div>
                                    <div class="col-xs-10">
                                        <h4 class="list-group-heading"><?php echo $view['translator']->trans(
                                                'mautic.promo.style.notification'
                                            ); ?></h4>
                                        <p class="list-group-item-text small"><?php echo $view['translator']->trans(
                                                'mautic.promo.style.notification_description'
                                            ); ?></p>
                                    </div>
                                </div>
                            </li>
                            <li class="promo-properties promo-notification-properties list-group-item pl-sm pr-sm" style="display: none;"></li>

                            <li data-promo-style="page" class="promo-style visible-promo-style-page list-group-item pl-sm pr-sm">
                                <div class="row">
                                    <div class="col-xs-2">
                                        <i class="pl-2 fa fa-2x fa-square text-danger"></i>
                                    </div>
                                    <div class="col-xs-10">
                                        <h4 class="list-group-heading"><?php echo $view['translator']->trans('mautic.promo.style.page'); ?></h4>
                                        <p class="list-group-item-text small"><?php echo $view['translator']->trans(
                                                'mautic.promo.style.page_description'
                                            ); ?></p>
                                    </div>
                                </div>
                            </li>
                            <!-- <li class="promo-properties promo-page-properties list-group-item pl-sm pr-sm" style="display: none;"></li> -->
                        </ul>
                    </div>

                    <div class="hide" id="promoStyleProperties">
                        <!-- bar type properties -->
                        <div class="promo-hide visible-promo-style-bar">
                            <?php echo $view['form']->row($form['properties']['bar']['allow_hide']); ?>
                            <?php echo $view['form']->row($form['properties']['bar']['push_page']); ?>
                            <?php echo $view['form']->row($form['properties']['bar']['sticky']); ?>
                            <?php echo $view['form']->row($form['properties']['bar']['placement']); ?>
                            <?php echo $view['form']->row($form['properties']['bar']['size']); ?>
                        </div>

                        <!-- modal type properties -->
                        <div class="promo-hide visible-promo-style-modal">
                            <?php echo $view['form']->row($form['properties']['modal']['placement']); ?>
                        </div>

                        <!-- notifications type properties -->
                        <div class="promo-hide visible-promo-style-notification">
                            <?php echo $view['form']->row($form['properties']['notification']['placement']); ?>
                        </div>

                        <!-- page type properties -->
                        <!-- <div class="promo-hide visible-promo-style-page"></div> -->
                    </div>
                </div>
                <!-- end promo style -->

                <!-- start promo colors -->
                <div class="panel panel-default" id="promoColors">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a role="button" data-toggle="collapse" href="#promoColorsPanel" aria-expanded="true" aria-controls="promoColorsPanel">
                                <i class="fa fa-paint-brush"></i> <?php echo $view['translator']->trans('mautic.promo.tab.promo_colors'); ?>
                            </a>
                        </h4>
                    </div>
                    <div id="promoColorsPanel" class="panel-collapse collapse" role="tabpanel">
                        <div class="panel-body pa-xs">
                            <div class="row">
                                <div class="form-group col-xs-12 ">
                                    <?php echo $view['form']->label($form['properties']['colors']['primary']); ?>
                                    <div class="input-group">
                                        <?php echo $view['form']->widget($form['properties']['colors']['primary']); ?>
                                        <span class="input-group-btn">
                                        <button data-dropper="promo_properties_colors_primary" class="btn btn-default btn-nospin btn-dropper" type="button"><i class="fa fa-eyedropper"></i></button>
                                    </span>
                                    </div>
                                    <div class="mt-xs site-color-list hide" id="primary_site_colors"></div>
                                    <?php echo $view['form']->errors($form['properties']['colors']['primary']); ?>
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group col-xs-12 ">
                                    <?php echo $view['form']->label($form['properties']['colors']['text']); ?>
                                    <div class="input-group">
                                        <?php echo $view['form']->widget($form['properties']['colors']['text']); ?>
                                        <span class="input-group-btn">
                                        <button data-dropper="promo_properties_colors_text" class="btn btn-default btn-nospin btn-dropper" type="button"><i class="fa fa-eyedropper"></i></button>
                                    </span>
                                    </div>
                                    <div class="mt-xs site-color-list hide" id="text_site_colors"></div>
                                    <?php echo $view['form']->errors($form['properties']['colors']['text']); ?>
                                </div>
                            </div>

                            <div class="hidden-promo-type-notice">

                                <div class="row">
                                    <div class="form-group col-xs-12 ">
                                        <?php echo $view['form']->label($form['properties']['colors']['button']); ?>
                                        <div class="input-group">
                                            <?php echo $view['form']->widget($form['properties']['colors']['button']); ?>
                                            <span class="input-group-btn">
                                        <button data-dropper="promo_properties_colors_button" class="btn btn-default btn-nospin btn-dropper" type="button"><i class="fa fa-eyedropper"></i></button>
                                    </span>
                                        </div>
                                        <div class="mt-xs site-color-list hide" id="button_site_colors"></div>
                                        <?php echo $view['form']->errors($form['properties']['colors']['button']); ?>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="form-group col-xs-12 ">
                                        <?php echo $view['form']->label($form['properties']['colors']['button_text']); ?>
                                        <div class="input-group">
                                            <?php echo $view['form']->widget($form['properties']['colors']['button_text']); ?>
                                            <span class="input-group-btn">
                                        <button data-dropper="promo_properties_colors_button_text" class="btn btn-default btn-nospin btn-dropper" type="button"><i class="fa fa-eyedropper"></i></button>
                                    </span>
                                        </div>
                                        <div class="mt-xs site-color-list hide" id="button_text_site_colors"></div>
                                        <?php echo $view['form']->errors($form['properties']['colors']['button_text']); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end promo colors -->

                <!-- start promo content -->
                <div class="panel panel-default" id="promoContent">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a role="button" data-toggle="collapse" href="#promoContentPanel" aria-expanded="true" aria-controls="promoContentPanel">
                                <i class="fa fa-newspaper-o"></i> <?php echo $view['translator']->trans('mautic.promo.tab.promo_content'); ?>
                            </a>
                        </h4>
                    </div>
                    <div id="promoContentPanel" class="panel-collapse collapse" role="tabpanel">
                        <div class="panel-body pa-xs">
                            <?php echo $view['form']->row($form['properties']['content']['headline']); ?>
                            <div class="hidden-promo-style-bar">
                                <?php echo $view['form']->row($form['properties']['content']['tagline']); ?>
                            </div>
                            <?php echo $view['form']->row($form['properties']['content']['font']); ?>

                            <!-- form type properties -->
                            <div class="promo-hide visible-promo-type-form">
                                <?php echo $view['form']->row($form['form']); ?>
                            </div>

                            <!-- link type properties -->
                            <div class="promo-hide visible-promo-type-link">
                                <?php echo $view['form']->row($form['properties']['content']['link_text']); ?>
                                <?php echo $view['form']->row($form['properties']['content']['link_url']); ?>
                                <?php echo $view['form']->row($form['properties']['content']['link_new_window']); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end promo content -->

            </div>
        </div>
    </div>

<?php echo $view['form']->end($form); ?>
