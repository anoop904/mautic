<?php

/*
 * @copyright   2016 Mautic, Inc. All rights reserved
 * @author      Mautic, Inc
 *
 * @link        https://mautic.org
 *
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

namespace MauticPlugin\MarketingFloorPromoBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class PropertiesType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add(
            'bar',
            'promo_properties',
            [
                'promo_style' => 'bar',
                'data'        => (isset($options['data']['bar'])) ? $options['data']['bar'] : [],
            ]
        );

        $builder->add(
            'modal',
            'promo_properties',
            [
                'promo_style' => 'modal',
                'data'        => (isset($options['data']['modal'])) ? $options['data']['modal'] : [],
            ]
        );

        $builder->add(
            'notification',
            'promo_properties',
            [
                'promo_style' => 'notification',
                'data'        => (isset($options['data']['notification'])) ? $options['data']['notification'] : [],
            ]
        );

        $builder->add(
            'page',
            'promo_properties',
            [
                'promo_style' => 'page',
                'data'        => (isset($options['data']['page'])) ? $options['data']['page'] : [],
            ]
        );

        $builder->add(
            'animate',
            'yesno_button_group',
            [
                'label' => 'mautic.promo.form.animate',
                'data'  => (isset($options['data']['animate'])) ? $options['data']['animate'] : true,
                'attr'  => [
                    'onchange' => 'Mautic.promoUpdatePreview()',
                ],
            ]
        );

        $builder->add(
            'link_activation',
            'yesno_button_group',
            [
                'label' => 'mautic.promo.form.activate_for_links',
                'data'  => (isset($options['data']['link_activation'])) ? $options['data']['link_activation'] : true,
                'attr'  => [
                    'data-show-on' => '{"promo_properties_when": ["leave"]}',
                ],
            ]
        );

        $builder->add(
            'colors',
            'promo_color',
            [
                'label' => false,
            ]
        );

        $builder->add(
            'content',
            'promo_content',
            [
                'label' => false,
            ]
        );

        $builder->add(
            'when',
            'choice',
            [
                'choices' => [
                    'immediately'   => 'mautic.promo.form.when.immediately',
                    'scroll_slight' => 'mautic.promo.form.when.scroll_slight',
                    'scroll_middle' => 'mautic.promo.form.when.scroll_middle',
                    'scroll_bottom' => 'mautic.promo.form.when.scroll_bottom',
                    'leave'         => 'mautic.promo.form.when.leave',
                ],
                'label'       => 'mautic.promo.form.when',
                'label_attr'  => ['class' => 'control-label'],
                'attr'        => ['class' => 'form-control'],
                'expanded'    => false,
                'multiple'    => false,
                'required'    => false,
                'empty_value' => false,
            ]
        );

        $builder->add(
            'timeout',
            'text',
            [
                'label'      => 'mautic.promo.form.timeout',
                'label_attr' => ['class' => 'control-label'],
                'attr'       => [
                    'class'          => 'form-control',
                    'postaddon_text' => 'sec',
                ],
                'required' => false,
            ]
        );

        $builder->add(
            'frequency',
            'choice',
            [
                'choices' => [
                    'everypage' => 'mautic.promo.form.frequency.everypage',
                    'once'      => 'mautic.promo.form.frequency.once',
                    'q2min'     => 'mautic.promo.form.frequency.q2m',
                    'q15min'    => 'mautic.promo.form.frequency.q15m',
                    'hourly'    => 'mautic.promo.form.frequency.hourly',
                    'daily'     => 'mautic.promo.form.frequency.daily',
                ],
                'label'       => 'mautic.promo.form.frequency',
                'label_attr'  => ['class' => 'control-label'],
                'attr'        => ['class' => 'form-control'],
                'expanded'    => false,
                'multiple'    => false,
                'required'    => false,
                'empty_value' => false,
            ]
        );

        $builder->add(
            'stop_after_conversion',
            'yesno_button_group',
            [
                'label' => 'mautic.promo.form.engage_after_conversion',
                'data'  => (isset($options['data']['stop_after_conversion'])) ? $options['data']['stop_after_conversion'] : true,
                'attr'  => [
                    'tooltip' => 'mautic.promo.form.engage_after_conversion.tooltip',
                ],
            ]
        );
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'promo_entity_properties';
    }

    /**
     * {@inheritdoc}
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(
            [
                'label' => false,
            ]
        );
    }
}
