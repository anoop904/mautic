<?php

/*
 * @copyright   2016 Mautic, Inc. All rights reserved
 * @author      Mautic, Inc
 *
 * @link        https://mautic.org
 *
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

namespace MauticPlugin\MarketingFloorPromoBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class PromoPropertiesType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        // Type specific
        switch ($options['promo_style']) {
            case 'bar':
                $builder->add(
                    'allow_hide',
                    'yesno_button_group',
                    [
                        'label' => 'mautic.promo.form.bar.allow_hide',
                        'data'  => (isset($options['data']['allow_hide'])) ? $options['data']['allow_hide'] : true,
                        'attr'  => [
                            'onchange' => 'Mautic.promoUpdatePreview()',
                        ],
                    ]
                );

                $builder->add(
                    'push_page',
                    'yesno_button_group',
                    [
                        'label' => 'mautic.promo.form.bar.push_page',
                        'attr'  => [
                            'tooltip'  => 'mautic.promo.form.bar.push_page.tooltip',
                            'onchange' => 'Mautic.promoUpdatePreview()',
                        ],
                        'data' => (isset($options['data']['push_page'])) ? $options['data']['push_page'] : true,
                    ]
                );

                $builder->add(
                    'sticky',
                    'yesno_button_group',
                    [
                        'label' => 'mautic.promo.form.bar.sticky',
                        'attr'  => [
                            'tooltip'  => 'mautic.promo.form.bar.sticky.tooltip',
                            'onchange' => 'Mautic.promoUpdatePreview()',
                        ],
                        'data' => (isset($options['data']['sticky'])) ? $options['data']['sticky'] : true,
                    ]
                );

                $builder->add(
                    'size',
                    'choice',
                    [
                        'choices' => [
                            'large'   => 'mautic.promo.form.bar.size.large',
                            'regular' => 'mautic.promo.form.bar.size.regular',
                        ],
                        'label'      => 'mautic.promo.form.bar.size',
                        'label_attr' => ['class' => 'control-label'],
                        'attr'       => [
                            'class'    => 'form-control',
                            'onchange' => 'Mautic.promoUpdatePreview()',
                        ],
                        'required'    => false,
                        'empty_value' => false,
                    ]
                );

                $choices = [
                    'top'    => 'mautic.promo.form.placement.top',
                    'bottom' => 'mautic.promo.form.placement.bottom',
                ];
                break;
            case 'modal':
                $choices = [
                    'top'    => 'mautic.promo.form.placement.top',
                    'middle' => 'mautic.promo.form.placement.middle',
                    'bottom' => 'mautic.promo.form.placement.bottom',
                ];
                break;
            case 'notification':
                $choices = [
                    'top_left'     => 'mautic.promo.form.placement.top_left',
                    'top_right'    => 'mautic.promo.form.placement.top_right',
                    'bottom_left'  => 'mautic.promo.form.placement.bottom_left',
                    'bottom_right' => 'mautic.promo.form.placement.bottom_right',
                ];
                break;
            case 'page':
                break;
        }

        if (!empty($choices)) {
            $builder->add(
                'placement',
                'choice',
                [
                    'choices'    => $choices,
                    'label'      => 'mautic.promo.form.placement',
                    'label_attr' => ['class' => 'control-label'],
                    'attr'       => [
                        'class'    => 'form-control',
                        'onchange' => 'Mautic.promoUpdatePreview()',
                    ],
                    'required'    => false,
                    'empty_value' => false,
                ]
            );
        }
    }

    public function getName()
    {
        return 'promo_properties';
    }

    /**
     * {@inheritdoc}
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setRequired(['promo_style']);

        $resolver->setDefaults(
            [
                'label' => false,
            ]
        );
    }
}
