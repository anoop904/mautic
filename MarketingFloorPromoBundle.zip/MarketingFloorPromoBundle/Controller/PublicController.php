<?php


namespace MauticPlugin\MarketingFloorPromoBundle\Controller;

use Mautic\CoreBundle\Controller\CommonController;
use Mautic\CoreBundle\Helper\TrackingPixelHelper;
use MauticPlugin\MarketingFloorPromoBundle\Entity\Stat;
use Symfony\Component\HttpFoundation\Response;

/**
 * Class class PublicController extends CommonController.
 */
class PublicController extends CommonController
{
    /**
     * @param $id
     *
     * @return array|\Symfony\Component\HttpFoundation\JsonResponse|\Symfony\Component\HttpFoundation\RedirectResponse|Response
     */
    public function generateAction($id)
    {
        /** @var \MauticPlugin\MarketingFloorPromoBundle\Model\PromoModel $model */
        $model = $this->getModel('promo');
        $promo = $model->getEntity($id);

        if ($promo) {
            if (!$promo->isPublished()) {
                return new Response('', 200, ['Content-Type' => 'application/javascript']);
            }

            $content  = (MAUTIC_ENV == 'dev') ? $model->generateJavascript($promo, false, true) : $model->getContent($promo);
            $response = new Response($content, 200, ['Content-Type' => 'application/javascript']);

            return $response;
        } else {
            return new Response('', 200, ['Content-Type' => 'application/javascript']);
        }
    }

    /**
     * @return Response
     */
    public function viewPixelAction()
    {
        $id = $this->request->get('id', false);
        if ($id) {
            /** @var \MauticPlugin\MarketingFloorPromoBundle\Model\PromoModel $model */
            $model = $this->getModel('promo');
            $promo = $model->getEntity($id);

            if ($promo && $promo->isPublished()) {
                $model->addStat($promo, Stat::TYPE_NOTIFICATION, $this->request, $this->getModel('lead')->getCurrentLead());
            }
        }

        $response = TrackingPixelHelper::getResponse($this->request);

        return $response;
    }
}
