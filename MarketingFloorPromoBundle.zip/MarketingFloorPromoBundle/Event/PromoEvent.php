<?php

/*
 * @copyright   2016 Mautic, Inc. All rights reserved
 * @author      Mautic, Inc
 *
 * @link        https://mautic.org
 *
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

namespace MauticPlugin\MarketingFloorPromoBundle\Event;

use Mautic\CoreBundle\Event\CommonEvent;
use MauticPlugin\MarketingFloorPromoBundle\Entity\Promo;

/**
 * Class PromoEvent.
 */
class PromoEvent extends CommonEvent
{
    /**
     * @param Promo      $promo
     * @param bool|false $isNew
     */
    public function __construct(Promo $promo, $isNew = false)
    {
        $this->entity = $promo;
        $this->isNew  = $isNew;
    }

    /**
     * Returns the Promo entity.
     *
     * @return Promo
     */
    public function getPromo()
    {
        return $this->entity;
    }

    /**
     * Sets the Promo entity.
     *
     * @param Promo $promo
     */
    public function setPromo(Promo $promo)
    {
        $this->entity = $promo;
    }
}
