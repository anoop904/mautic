<?php


return [
    'name'        => 'Marketing floor promo',
    'description' => 'Drive visitor\'s promo on your website with Marketing Floor promo',
    'version'     => '1.0',
    'author'      => 'Anoop',

    'routes' => [
        'main' => [
            'mautic_marketingfloor_promo_index' => [
                'path'       => '/promo/{page}',
                'controller' => 'MarketingFloorPromoBundle:Promo:index',
            ],
            'mautic_marketingfloor_promo_action' => [
                'path'       => '/promo/{objectAction}/{objectId}',
                'controller' => 'MarketingFloorPromoBundle:Promo:execute',
            ],
        ],
        'public' => [
            'mautic_marketingfloor_promo_generate' => [
                'path'       => '/promo/{id}.js',
                'controller' => 'MarketingFloorPromoBundle:Public:generate',
            ],
            'mautic_marketingfloor_promo_pixel' => [
                'path'       => '/promo/{id}/viewpixel.gif',
                'controller' => 'MarketingFloorPromoBundle:Public:viewPixel',
            ],
        ],
    ],

    'services' => [
        'events' => [
            'marketingfloor.promo.subscriber.form_bundle' => [
                'class'     => 'MauticPlugin\MarketingFloorPromoBundle\EventListener\FormSubscriber',
                'arguments' => [
                    'mautic.marketingfloor.model.promo',
                ],
            ],
            'marketingfloor.promo.subscriber.page_bundle' => [
                'class'     => 'MauticPlugin\MarketingFloorPromoBundle\EventListener\PageSubscriber',
                'arguments' => [
                    'mautic.marketingfloor.model.promo',
                    'router',
                ],
            ],
            'marketingfloor.promo.subscriber.stat' => [
                'class'     => 'MauticPlugin\MarketingFloorPromoBundle\EventListener\StatSubscriber',
                'arguments' => [
                    'mautic.marketingfloor.model.promo',
                ],
            ],
            'marketingfloor.promo.subscriber.promo' => [
                'class'     => 'MauticPlugin\MarketingFloorPromoBundle\EventListener\PromoSubscriber',
                'arguments' => [
                    'router',
                    'mautic.helper.ip_lookup',
                    'mautic.core.model.auditlog',
                ],
            ],
            'marketingfloor.promo.stats.subscriber' => [
                'class'     => \MauticPlugin\MarketingFloorPromoBundle\EventListener\StatsSubscriber::class,
                'arguments' => [
                    'doctrine.orm.entity_manager',
                ],
            ],
        ],
        'forms' => [
            'marketingfloor.promo.form.type.color' => [
                'class' => 'MauticPlugin\MarketingFloorPromoBundle\Form\Type\ColorType',
                'alias' => 'promo_color',
            ],
            'marketingfloor.promo.form.type.content' => [
                'class' => 'MauticPlugin\MarketingFloorPromoBundle\Form\Type\ContentType',
                'alias' => 'promo_content',
            ],
            'marketingfloor.promo.form.type.promo' => [
                'class'     => 'MauticPlugin\MarketingFloorPromoBundle\Form\Type\PromoType',
                'alias'     => 'promo',
                'arguments' => 'mautic.security',
            ],
            'marketingfloor.promo.form.type.entity_properties' => [
                'class' => 'MauticPlugin\MarketingFloorPromoBundle\Form\Type\PropertiesType',
                'alias' => 'promo_entity_properties',
            ],
            'marketingfloor.promo.form.type.properties' => [
                'class' => 'MauticPlugin\MarketingFloorPromoBundle\Form\Type\PromoPropertiesType',
                'alias' => 'promo_properties',
            ],
        ],
        'models' => [
            'mautic.marketingfloor.model.promo' => [
                'class'     => 'MauticPlugin\MarketingFloorPromoBundle\Model\PromoModel',
                'arguments' => [
                    'mautic.form.model.form',
                    'mautic.page.model.trackable',
                    'mautic.helper.templating',
                ],
            ],
        ],
        'other' => [
            'marketingfloor.promo.helper.token' => [
                'class'     => 'MauticPlugin\MarketingFloorPromoBundle\Helper\TokenHelper',
                'arguments' => [
                    'mautic.marketingfloor.model.promo',
                    'router',
                ],
            ],
        ],
    ],

    'menu' => [
        'main' => [
            'marketingfloor.promo' => [
                'route'    => 'mautic_mautic_marketingfloor_promo_index',
                'access'   => 'plugin:promo:items:view',
                'parent'   => 'mautic.core.channels',
                'priority' => 10,
            ],
        ],
    ],

    'categories' => [
        'plugin:promo' => 'mautic.promo',
    ],

    'parameters' => [
        'website_snapshot_url' => 'https://mautic.net/api/snapshot',
        'website_snapshot_key' => '',
    ],
];
